# BasicAudio

Demonstrates how to deal with audio in JUCE. Implements a simple sine wave oscillator from scratch where the frequency and the gain can be controlled using sliders and a checkbox allows to turn it on or off.

---

Implemented by Romain Michon (rmichonATccrmaDOTstanfordDOTedu) for Music 256a / CS 476a (fall 2016).